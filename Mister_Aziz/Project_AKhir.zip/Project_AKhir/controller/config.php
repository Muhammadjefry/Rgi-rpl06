<?php
$conn = mysqli_connect('localhost','root','','A_project_akhir') or die('connection failed');

?>