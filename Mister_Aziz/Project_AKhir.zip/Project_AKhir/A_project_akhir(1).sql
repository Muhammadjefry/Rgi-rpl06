-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 25, 2023 at 03:31 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `A_project_akhir`
--

-- --------------------------------------------------------

--
-- Table structure for table `antrian2`
--

DROP TABLE IF EXISTS `antrian2`;
CREATE TABLE `antrian2` (
  `id` int(11) NOT NULL,
  `login_id` varchar(225) NOT NULL,
  `tlp` varchar(255) NOT NULL,
  `poli` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `no_antrian` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `antrian2`
--

INSERT INTO `antrian2` (`id`, `login_id`, `tlp`, `poli`, `tanggal`, `no_antrian`) VALUES
(1, 'Muhammad jefry', '+6281224506675', 'umum', '2023-11-25', 1),
(2, 'Muhammad jefry', '+6281224506675', 'gigi', '2023-11-25', 1),
(3, 'Muhammad walid', '+628973830176', 'umum', '2023-11-25', 2),
(4, 'Muhammad nazal', '+6283155618443', 'umum', '2023-11-25', 3);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `name` varchar(200) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `tlp` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `level` varchar(100) NOT NULL DEFAULT 'pasien'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `nik`, `name`, `gender`, `date`, `tlp`, `username`, `password`, `level`) VALUES
(1, '', 'admin', '', '2023-11-21', '', 'admin@gmail.com', '0192023a7bbd73250516f069df18b500', 'admin'),
(2, '', 'umum', '', '2023-11-21', '', 'umum@gmail.com', 'f5df3bde70b7b7ab67ce0e00edcb1951', 'Umum'),
(3, '', 'gigi', '', '2023-11-21', '', 'gigi@gmail.com', 'd91ec1d45535ebf3d8f6882217d10676', 'Gigi'),
(4, '', 'gizi', '', '2023-11-21', '', 'gizi@gmail.com', '00c08ae98427567f86e1ec0660d629ad', 'Gizi'),
(5, '', 'kia', '', '2023-11-21', '', 'kia@gmail.com', 'cbf260c077bab9519328e29ce020979f', 'Kia'),
(6, '', 'batra', '', '2023-11-21', '', 'batra@gmail.com', 'fd0f2e1b3aaabb732fa038442c9c0a6d', 'Batra'),
(7, '', 'lansia', '', '2023-11-21', '', 'lansia@gmail.com', 'fbfa915dee41bc9bc043dc2c72040dbd', 'Lansia'),
(8, '', 'psikologi', '', '2023-11-21', '', 'psikologi@gmail.com', '3bb94e9c5efe3bb346ba2d762f7ca672', 'Psikologi'),
(9, '', 'paru', '', '2023-11-21', '', 'paru@gmail.com', '664dc5e2a9e90dc5dc1376d4adf6df23', 'Paru'),
(10, '2131134124314141', 'Muhammad agung', 'pria', '2023-12-29', '+6281808823587', 'agung@gmail.com', '6f5d0ad4bc971cddc51a0c5f74bdf3fd', 'pasien'),
(11, '5238313242423423', 'Muhammad nazal', 'pria', '2023-12-02', '+6283155618443', 'nazal@gmail.com', '181785b9c92557cdf5f8051b1de010bb', 'pasien'),
(12, '4552345234234324', 'Muhammad walid', 'pria', '2023-12-08', '+628973830176', 'walid@gmail.com', 'f74566e73adec638e2198016b0d6cbdf', 'pasien'),
(13, '3243242342343242', 'Maulanana Mario ', 'pria', '2023-12-16', '+6285932512242', 'mario@gmail.com', 'aeb34368c5d53aee32431b5386f71c56', 'pasien'),
(14, '6345345243234234', 'Maulana faqih', 'pria', '2023-12-02', '+6287816563581', 'faqih@gmail.com', 'a06b4b19fe52bf06af90aa7eea03a601', 'pasien'),
(15, '4432423423423423', 'Rifky ', 'pria', '2023-12-16', '+6289648170919', 'rifky@gmail.com', '10b083dd59d8ac9834250f397bc55bb9', 'pasien'),
(16, '3123123123131231', 'Rusnanto', 'pria', '2023-12-23', '+6281224628643', 'rus@gmail.com', 'f8e30fbfd0275f7f283f0a1c0b072904', 'pasien'),
(17, '3211231231231312', 'Muhammad jefry', 'pria', '2023-12-20', '+6281224506675', 'jefry@gmail.com', 'b0feaf8fa06f27daafc0e2af68f62d49', 'pasien'),
(18, '3431231231231231', 'Sulthon Dai', 'pria', '2023-12-22', '+6287744055279', 'sulthon@gmail.com', 'c0598a36a17559127be51d96e86946ea', 'pasien');

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

DROP TABLE IF EXISTS `pasien`;
CREATE TABLE `pasien` (
  `id` int(11) NOT NULL,
  `login_id` varchar(225) NOT NULL,
  `tanggal` date NOT NULL,
  `keluhan` varchar(255) NOT NULL,
  `diagnosis` varchar(255) NOT NULL,
  `tindakan` varchar(255) NOT NULL,
  `obat` varchar(255) NOT NULL,
  `dosis` varchar(255) NOT NULL,
  `frekuensi` varchar(255) NOT NULL,
  `poli` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`id`, `login_id`, `tanggal`, `keluhan`, `diagnosis`, `tindakan`, `obat`, `dosis`, `frekuensi`, `poli`) VALUES
(1, 'Muhammad jefry', '2023-11-25', 'Sakit kepala persisten', '\n    Asma', 'istirahat', 'paramex', '50 mg', 'Sesuai kebutuhan', 'paru'),
(2, 'Muhammad jefry', '2023-11-25', 'Sesak napas', '\n    Asma', 'istirahat', 'paramex', '500 m', 'Saat timbul migrain', 'paru'),
(3, 'Muhammad jefry', '2023-11-25', 'Sakit kepala persisten', '\n    Asma', 'istirahat', 'paramex', '50 mg', 'Saat timbul migrain', 'umum'),
(4, 'Muhammad jefry', '2023-11-25', 'Sesak napas', '\n    Infeksi saluran pernapasan atas', 'istirahat', 'Sumatriptan', '50 mg', 'Sesuai kebutuhan', 'umum');

-- --------------------------------------------------------

--
-- Table structure for table `pasienT`
--

DROP TABLE IF EXISTS `pasienT`;
CREATE TABLE `pasienT` (
  `id` int(11) NOT NULL,
  `login_id` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `keluhan` varchar(255) NOT NULL,
  `diagnosis` varchar(255) NOT NULL,
  `tindakan` varchar(255) NOT NULL,
  `obat` varchar(255) NOT NULL,
  `dosis` varchar(255) NOT NULL,
  `frekuensi` varchar(255) NOT NULL,
  `poli1` varchar(255) NOT NULL,
  `poli2` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pasienT`
--

INSERT INTO `pasienT` (`id`, `login_id`, `tanggal`, `keluhan`, `diagnosis`, `tindakan`, `obat`, `dosis`, `frekuensi`, `poli1`, `poli2`) VALUES
(1, 'Muhammad jefry', '2023-11-25', 'Sakit kepala persisten', '\n    Asma', 'istirahat', 'Paracetamol', '500 m', 'Sesuai kebutuhan', 'umum', 'paru'),
(2, 'Muhammad jefry', '2023-11-25', 'Sakit kepala persisten', '\n    Asma', 'istirahat', 'paramex', '500 m', 'Saat timbul migrain', 'umum', 'paru'),
(3, 'Muhammad jefry', '2023-11-25', 'Sesak napas', '\n    Infeksi saluran pernapasan atas', 'istirahat', 'Paracetamol', '500 m', 'Sesuai kebutuhan', 'umum', 'paru'),
(4, 'Muhammad jefry', '2023-11-25', 'flu', '\n    Asma', 'istirahat', 'paramex', '50 mg', 'Sesuai kebutuhan', 'umum', 'psikologi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `antrian2`
--
ALTER TABLE `antrian2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pasienT`
--
ALTER TABLE `pasienT`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `antrian2`
--
ALTER TABLE `antrian2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pasienT`
--
ALTER TABLE `pasienT`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
