<?php 
// include "../includes/conn.php";
// session_start();

// if(isset($_POST['submit'])){
//     $id  = $_POST['id'];
//     $sql = "DELETE FROM antrian WHERE id='$id'";
//     if($conn->query($sql)){
//         $_SESSION['success'] = "Record has been successfully deleted";
//     }else{
//         $_SESSION['error'] = "No record deleted";
//     }
// }else{
//     $_SESSION['success'] = "Please select first the record to delete";
// }
// header("location:../view/pasien.php");
?>