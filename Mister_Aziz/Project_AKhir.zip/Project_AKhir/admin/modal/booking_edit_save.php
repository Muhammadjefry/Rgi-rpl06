<?php
// session_start(); // Pastikan telah memulai sesi

// include "../includes/conn.php";
// if (isset($_POST['submit'])) {
//     $id = $_POST['id'];
//     $nama = $_POST['nama'];
//     $nik = $_POST['nik'];
//     $phone = $_POST['phone'];
//     $username = $_POST['username'];
//     $no_antrian = $_POST['no_antrian'];

//     $sql = "UPDATE antrian SET nama='$nama', nik='$nik', phone='$phone', username='$username', no_antrian='$no_antrian' WHERE id='$id'";

//     if ($conn->query($sql)) {
//         $_SESSION['success'] = "Client information successfully updated!!";
//     } else {
//         $_SESSION['error'] = $conn->error;
//     }
// } else {
//     $_SESSION['error'] = "Please select a client to edit";
// }

// header('location:umum.php'); // Mengarahkan kembali ke halaman utama
?>