<?php
// include "../includes/conn.php";
// session_start();

// if (isset($_POST['submit'])) {
//     $id = $_POST['id'];
//     $keterangan = $_POST['keterangan'];

//     // Assuming you have a valid login_id (replace 123 with the actual value)
//     $login_id = 123;

//     // Use INSERT INTO for adding a new record
//     $sql = "INSERT INTO antrian2 (login_id, keterangan) VALUES ('$login_id', '$keterangan')";

//     if ($conn->query($sql)) {
//         $_SESSION['success'] = "Record has been successfully inserted";
//     } else {
//         $_SESSION['error'] = $conn->error;
//     }
// } else {
//     $_SESSION['error'] = "Please select first the record to insert";
// }

// header("location:../poli/poli.php");
?>