<?php
// session_start(); // Pastikan telah memulai sesi

// include "../includes/conn.php";
// if (isset($_POST['submit'])) {
//     $id = $_POST['id'];
//     $nama  = $_POST['nama'];
//     $visit_date  = $_POST['visit_date'];
//     $weight  = $_POST['weight'];
//     $height  = $_POST['height'];
//     $blood_pressure  = $_POST['blood_pressure'];
//     $cholesterol_level  = $_POST['cholesterol_level'];
//     $diagnosis  = $_POST['diagnosis'];
//     $prescription  = $_POST['prescription'];

//     $sql = "UPDATE poli_umum SET nama='$nama', weight='$weight', height='$height', blood_pressure='$blood_pressure', cholesterol_level='$cholesterol_level', diagnosis='$diagnosis', prescription='$prescription'  WHERE id='$id'";

//     if ($conn->query($sql)) {
//         $_SESSION['success'] = "Client information successfully updated!!";
//     } else {
//         $_SESSION['error'] = $conn->error;
//     }
// } else {
//     $_SESSION['error'] = "Please select a client to edit";
// }

// header('location:../pasien/pasien_umum.php'); // Mengarahkan kembali ke halaman utama
?>