<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>


<?php if( is_user_logged_in() ) { ?>
	<div id="kanvas">
		<button id="hadir">PEKO!</button>
		<br/>
		<p>This site is only accessible by devices connected to the same network.</p>
	</div>

	<script>
function gel(el) {
	return document.querySelector(el);
}

gel('#hadir').addEventListener('click', function(e) {
	const d = new FormData();
	d.append('action','absen');
	
	fetch(absensi_misc_data.ajax_url, {
		method: "POST",
		credentials: 'same-origin',
		body: d
	})
	.then((response) => response.json())
	.then((data) => {
		console.log(data);
	})
	.catch((error) => {
		console.log(error);
	});
});
	</script>
<?php } else { ?>
	<h2>Who?</h2>
<?php } ?>


	
<?php wp_footer(); ?>
</body>
</html>