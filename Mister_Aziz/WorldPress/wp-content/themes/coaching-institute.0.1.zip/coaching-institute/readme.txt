=== Coaching Institute ===
Contributors: Luzuk
Tags: one-column, two-columns, right-sidebar, left-sidebar, grid-layout, custom-colors, custom-background, custom-header, custom-menu, custom-logo, editor-style, footer-widgets, full-width-template, flexible-header, sticky-post, theme-options, threaded-comments, blog, portfolio, e-commerce
Requires at least: 5.0
Tested up to: 6.1
Requires PHP: 7.2
Stable tag: 0.1
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Coaching Institute the ideal an most suitable theme for construction, construction theme, creative, industrial, industrial machinery, Industrial Products, industry, industry theme, machinery products, manufacturing industry, metallurgy, modern, oil, Oil Industries.

== Description ==

We present Coaching Institute WordPress Theme for people offering coaching and want to take their services online. You may be a life coach, coding coach, job interview coach, or teach other regular subjects.  Coaching Institute WordPress Theme is going to work for you. 
We’ve designed the theme in a way that will help you to balance visuals and information (content) perfectly. We understand that visuals that you may decide to use in headers or in other spaces will also speak to your audience and help them to create an impression of you in their mind. The navigation structure of Coaching Institute WordPress Theme creates a perfect and logical sequence of information flow. 
You may be new to the idea of taking your coaching services online as till now you’ve been getting clients through word of mouth and traditional marketing means.  However in this era of digitalization you can’t afford to miss or delay the opportunity of creating an online presence.  If you are planning to take your services on the net the easiest and most affordable way to do it is using our Coaching Institute WordPress Theme. The design is free to use, easy to operate, you can download and install in within minutes. If you have a domain name and hosting space (if you don’t, get one), this theme is a blessing, and you can create an online presence for your coaching classes in minutes. 
You can publish information about yourself, your experience, expertise, types of coaching classes you offer, how enrolled individuals will benefit with your course. The dashboard is very easy to operate, with a little practice, you’re good to go! You can change colors, fonts, images, place links to your social media handles, email id, action buttons etc. as per your requirements and theme.
Coaching Institute WordPress Theme is compatible on all browsers and devices. It’s a responsive website where people can get in touch with you; send you mails to enquire details. You can roll out announcements of classes.
If you want to take your coaching profession online and drive more traffic, Coaching Institute WordPress Theme can prove to be your best and most effective bet. Go for it. Trust our word, it’s very easy to download, install and maintain. No paying designing charges and breaking your head with web designers. Coaching Institute WordPress Theme is at your service!


For Homepage Setup:
====================

1. Go to Dashboard >> Pages >> Add New, Create a new page and name it as "Home" then select the template "Custom Home Page" and publish it.

2. Go to Dashboard >> Settings >> Reading, Select the option of Static Page, now select the page you created to be the homepage.

For Header Section:
====================

1. Go to Dashboard >> Appearance >> Customizer >> Theme Settings >> Header Section, add topbar text, add phone text, add phone number and publish it.

For Slider:
============

1. Go to Dashboard >> Pages >> Add New, Create a new Page and name it, add the content, serviced image and publish the page. Repeat this step for other sliders.

2. Go to Dashboard >> Appearance >> Customizer >> Theme Settings >> Slider Settings, Click the checkbox of Show/Hide Slider, select the pages of the slider that you have created and publish it.

For Service Section:
====================

1. Go to Dashboard >> Posts >> Category, add new category for service, name it and publish it.

2. Go to Dashboard >> Posts >> Add New, Create a new Post and name it, assign the service category and publish the post. Repeat the step for other service posts.

2. Go to Customizer >> Theme Settings >> Service Section, select the service category that you have created, you can also change the number of post to show & icons of service and publish it.

For Service Section:
====================

1. Go to Dashboard >> Posts >> Category, add new category for services, name it and publish it.

2. Go to Dashboard >> Posts >> Add New, Create a new Post and name it, assign the service category and publish the post. Repeat the step for other service posts.

2. Go to Customizer >> Theme Settings >> Service Section, add section title, select the service category that you have created and publish it.

For Footer Section:
====================

1. Go to Dashboard >> Appearance >> Widgets, here you can add widgets to the footer widgets areas, which can be seen in footer.

For Copyright Text:
====================

1. Go to Customizer >> Theme Settings >> Footer Text, add footer text here and it also have an option to show/hide back to top.

== Resources ==

Coaching Institute WordPress Theme, Copyright 2022 Luzuk
Coaching Institute is distributed under the terms of the GNU GPL

Coaching Institute bundles the following third-party resources:

* Bootstrap
  - Mark Otto and Jacob Thornton
  - copyright 2011-2018, Mark Otto and Jacob Thornton
  - https://github.com/twbs/bootstrap/releases/download/v4.0.0/bootstrap-4.0.0-dist.zip 
  - License: MIT License (MIT)
  - https://github.com/twbs/bootstrap/blob/master/LICENSE

* Font Awesome
  - Dave Gandy
  - Copyright July 12, 2018, Dave Gandy 
  - https://github.com/FortAwesome/Font-Awesome.git
  - License: Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License
  - http://fontawesome.com/license

* Superfish
  - Joeldbirch
  - Copyright 2013, Justin Tadlock 
  - https://github.com/joeldbirch/superfish.git 
  - License: Free to use and abuse under the MIT license. v1.7.9 
  - https://github.com/joeldbirch/superfish/blob/master/MIT-LICENSE.txt

* PSR-4 autoloader
  - Justin Tadlock
  - License: https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
  - Source: https://github.com/WPTRT/autoload

* CustomizeSectionButton
  - Justin Tadlock
  - Copyright 2019, Justin Tadlock.
  - License: https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
  - https://github.com/WPTRT/customize-section-button

* Webfonts Loader
  - https://github.com/WPTT/webfont-loader
  - License: https://github.com/WPTT/webfont-loader/blob/master/LICENSE

* Screenshot Images
   	PxHere Images
  	License: CC0 1.0 Universal (CC0 1.0) 
  	Source: https://pxhere.com/en/license

    Slider image
    License: CC0 1.0 Universal (CC0 1.0)
    Source: https://pxhere.com/en/photo/1452903

    About Us image
    License: CC0 1.0 Universal (CC0 1.0)
    Source: https://pxhere.com/en/photo/1629587

    About Us image
    License: CC0 1.0 Universal (CC0 1.0)
    Source: https://pxhere.com/en/photo/1629588
    
== Changelog ==

= 0.1 =
  - Initial Version Released.