<div data-colibri-id="7-h29" class="h-lead h-text h-text-component style-23 style-local-7-h29 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <div>
    <p>
      <?php $component->printSubtitle(); ?>
    </p>
  </div>
</div>
