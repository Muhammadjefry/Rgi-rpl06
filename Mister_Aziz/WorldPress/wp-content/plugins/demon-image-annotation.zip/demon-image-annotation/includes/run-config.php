<?php

global $wpdb;
define( 'DIA_TABLE_NOTES', $wpdb->prefix . 'demon_imagenote' );
define( 'DIA_TABLE_COMMENTS', $wpdb->prefix . 'comments' );
