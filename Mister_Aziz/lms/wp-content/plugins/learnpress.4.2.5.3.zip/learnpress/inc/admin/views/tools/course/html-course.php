<?php
/**
 * @author  ThimPress
 * @package LearnPress/Admin/Views
 * @version 3.0.0
 */

defined( 'ABSPATH' ) or die();

// Cannot delete id 'learn-press-reset-course-users' - xoa la khong dc dau
?>

<div id="learn-press-reset-course-users" class="card"></div>
